const XLSX = require('xlsx');
 
const Janurary = ["C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 01-04-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 01-05-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 01-06-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 01-07-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 01-10-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 01-11-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 01-12-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 01-13-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 01-18-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 01-19-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 01-20-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 01-21-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 01-24-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 01-25-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 01-26-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 01-27-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 01-28-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 01-31-22.xlsx",
];
const Feburary = ["C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 02-01-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 02-02-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 02-03-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 02-04-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 02-07-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 02-08-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 02-09-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 02-10-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 02-11-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 02-14-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 02-15-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 02-16-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 02-17-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 02-18-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 02-21-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 02-22-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 02-23-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 02-24-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 02-25-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 02-28-22.xlsx"];

const March = ["C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-01-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-02-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-03-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-04-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-07-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-08-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-09-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-10-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-11-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-14-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-15-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-16-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-17-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-18-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-21-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-22-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-23-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-24-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-25-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-28-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-29-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-30-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 03-31-22.xlsx"
];
const April = [
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 04-01-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 04-04-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 04-05-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 04-06-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 04-07-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 04-08-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 04-11-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 04-12-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 04-13-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 04-14-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 04-18-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 04-19-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 04-20-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 04-21-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 04-22-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 04-25-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 04-26-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 04-27-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 04-28-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 04-29-22.xlsx"];

const May = [
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 05-02-2022.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 05-03-2022.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 05-04-2022.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 05-05-2022.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 05-06-2022.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 05-09-2022.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 05-10-2022.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 05-11-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 05-12-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 05-13-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 05-16-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 05-17-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 05-18-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 05-19-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 05-20-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 05-23-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 05-24-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 05-25-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 05-26-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 05-27-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 05-31-22.xlsx"
];

const June = [
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 06-1-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 06-2-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 06-3-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 06-6-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 06-7-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 06-8-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 06-9-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 06-10-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 06-13-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 06-14-22.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 06-15-2022.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 06-16-2022.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 06-17-2022.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 06-20-2022.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 06-21-2022.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 06-22-2022.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 06-23-2022.xlsx",
"C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 06-24-2022.xlsx",

];

 /* function formatAsPercent(num) {return new Intl.NumberFormat('default', {style: 'percent', minimumFractionDigits: 2,
maximumFractionDigits: 2, }).format(num);} */    
 /*

for (const element of Janurary) {
  var workbook = XLSX.readFile(element);
  let worksheet = workbook.Sheets[workbook.SheetNames[0]];
  const dataExcel = XLSX.utils.sheet_to_json(worksheet);  
  var address_of_cell = 'K7';
  var desired_cell = worksheet[address_of_cell];
  var desired_value = desired_cell.v;
let element1 = element.replace("C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount ", "");  
let element2 = element1.replace(".xlsx", "");  
var quote  = "\"";  
var c= "{t: new Date("+quote+ element2+quote+")" +"," + "  y: " + desired_value*100 +"},";  
console.log(c);
 
} 
*/ 
 /*

for (const element of Janurary) {
  var workbook = XLSX.readFile(element);
  let worksheet = workbook.Sheets[workbook.SheetNames[0]];
  const dataExcel = XLSX.utils.sheet_to_json(worksheet);  
  var address_of_cell = 'K6';
  var desired_cell = worksheet[address_of_cell];
  var desired_value = desired_cell.v;    
let element1 = element.replace("C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount ", "");  
let element2 = element1.replace(".xlsx", "");  
var quote  = "\"";  
var c= "{t: new Date("+quote+ element2+quote+")" +"," + "  y: " + desired_value*100 +"},";  
console.log(c);
//  console.log(element2+"  "+formatAsPercent(desired_value));
}

*/ 

 /*


for (const element of Janurary) {
  var workbook = XLSX.readFile(element);
  let worksheet = workbook.Sheets[workbook.SheetNames[0]];
  const dataExcel = XLSX.utils.sheet_to_json(worksheet);  
  var address_of_cell = 'K8';
  var desired_cell = worksheet[address_of_cell];
  var desired_value = desired_cell.v;    
let element1 = element.replace("C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount ", "");  
let element2 = element1.replace(".xlsx", "");  
var quote  = "\"";  
var c= "{t: new Date("+quote+ element2+quote+")" +"," + "  y: " + desired_value*100 +"},";  
console.log(c);
//  console.log(element2+"  "+formatAsPercent(desired_value));
}
*/  

 /*
for (const element of Janurary) {
  var workbook = XLSX.readFile(element);
  let worksheet = workbook.Sheets[workbook.SheetNames[0]];
  const dataExcel = XLSX.utils.sheet_to_json(worksheet);  
  var address_of_cell = 'K9';
  var desired_cell = worksheet[address_of_cell];
  var desired_value = desired_cell.v;    
let element1 = element.replace("C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount ", "");  
let element2 = element1.replace(".xlsx", "");  
var quote  = "\"";  
var c= "{t: new Date("+quote+ element2+quote+")" +"," + "  y: " + desired_value*100 +"},";  
console.log(c);

}

*/  


 /*
for (const element of Janurary) {
  var workbook = XLSX.readFile(element);
  let worksheet = workbook.Sheets[workbook.SheetNames[0]];
  const dataExcel = XLSX.utils.sheet_to_json(worksheet);  
  var address_of_cell = 'K10';
  var desired_cell = worksheet[address_of_cell];
  var desired_value = desired_cell.v;    
let element1 = element.replace("C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount ", "");  
let element2 = element1.replace(".xlsx", "");  
var quote  = "\"";  
var c= "{t: new Date("+quote+ element2+quote+")" +"," + "  y: " + desired_value*100 +"},";  
console.log(c);

}
*/  
 /*
for (const element of Janurary) {
  var workbook = XLSX.readFile(element);
  let worksheet = workbook.Sheets[workbook.SheetNames[0]];
  const dataExcel = XLSX.utils.sheet_to_json(worksheet);  
  var address_of_cell = 'K11';
  var desired_cell = worksheet[address_of_cell];
  var desired_value = desired_cell.v;    
let element1 = element.replace("C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount ", "");  
let element2 = element1.replace(".xlsx", "");  
var quote  = "\"";  
var c= "{t: new Date("+quote+ element2+quote+")" +"," + "  y: " + desired_value*100 +"},";  
console.log(c);

}

*/  

/*
for (const element of Janurary) {
  var workbook = XLSX.readFile(element);
  let worksheet = workbook.Sheets[workbook.SheetNames[0]];
  const dataExcel = XLSX.utils.sheet_to_json(worksheet);  
  var address_of_cell = 'J6';
  var desired_cell = worksheet[address_of_cell];
  var desired_value = desired_cell.v;    
let element1 = element.replace("C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount ", "");  
let element2 = element1.replace(".xlsx", "");  
var quote  = "\"";  
var c= "{t: new Date("+quote+ element2+quote+")" +"," + "  y: " + desired_value +"},";  
console.log(c);

}


// Please take out last comma. 














/*

var workbook = XLSX.readFile("C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 01-04-22.xlsx");
let worksheet = workbook.Sheets[workbook.SheetNames[0]];
const dataExcel = XLSX.utils.sheet_to_json(worksheet);  
var address_of_cell = 'K7';
var desired_cell = worksheet[address_of_cell];
var desired_value = desired_cell.v;
function formatAsPercent(num) {
    return new Intl.NumberFormat('default', {
      style: 'percent',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(num);}
  console.log(formatAsPercent(desired_value));


var workbook1 = XLSX.readFile("C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount 01-05-22.xlsx");
let worksheet1 = workbook1.Sheets[workbook1.SheetNames[0]];
const dataExcel1 = XLSX.utils.sheet_to_json(worksheet1);  
var address_of_cell1 = 'K7';
var desired_cell1 = worksheet1[address_of_cell1];
var desired_value1 = desired_cell1.v;
function formatAsPercent(num) {
    return new Intl.NumberFormat('default', {
      style: 'percent',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(num);}
  console.log(formatAsPercent(desired_value1));

  */ 

/*
  for (const element of Janurary) {
    var workbook = XLSX.readFile(element);
    let worksheet = workbook.Sheets[workbook.SheetNames[0]];
    const dataExcel = XLSX.utils.sheet_to_json(worksheet);  
    var address_of_cell = 'K12';
    var desired_cell = worksheet[address_of_cell];
    var desired_value = desired_cell.v;    
  let element1 = element.replace("C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount ", "");  
  let element2 = element1.replace(".xlsx", "");  
  var quote  = "\"";  
  var c= "{t: new Date("+quote+ element2+quote+")" +"," + "  y: " + desired_value*100 +"},";  
  console.log(c);
  //  console.log(element2+"  "+formatAsPercent(desired_value));
  }


  */ 

/*
  for (const element of Janurary) {
    var workbook = XLSX.readFile(element);
    let worksheet = workbook.Sheets[workbook.SheetNames[0]];
    const dataExcel = XLSX.utils.sheet_to_json(worksheet);  
    var address_of_cell = 'J7';
    var desired_cell = worksheet[address_of_cell];
    var desired_value = desired_cell.v;    
  let element1 = element.replace("C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount ", "");  
  let element2 = element1.replace(".xlsx", "");  
  var quote  = "\"";  
  var c= "{t: new Date("+quote+ element2+quote+")" +"," + "  y: " + desired_value*100 +"},";  
  console.log(c);
  }  */ 
/*
  for (const element of Janurary) {
    var workbook = XLSX.readFile(element);
    let worksheet = workbook.Sheets[workbook.SheetNames[0]];
    const dataExcel = XLSX.utils.sheet_to_json(worksheet);  
    var address_of_cell = 'J8';
    var desired_cell = worksheet[address_of_cell];
    var desired_value = desired_cell.v;    
  let element1 = element.replace("C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount ", "");  
  let element2 = element1.replace(".xlsx", "");  
  var quote  = "\"";  
  var c= "{t: new Date("+quote+ element2+quote+")" +"," + "  y: " + desired_value*100 +"},";  
  console.log(c);
  }

 */ 
/*
  for (const element of Janurary) {
    var workbook = XLSX.readFile(element);
    let worksheet = workbook.Sheets[workbook.SheetNames[0]];
    const dataExcel = XLSX.utils.sheet_to_json(worksheet);  
    var address_of_cell = 'J12';
    var desired_cell = worksheet[address_of_cell];
    var desired_value = desired_cell.v;    
  let element1 = element.replace("C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount ", "");  
  let element2 = element1.replace(".xlsx", "");  
  var quote  = "\"";  
  var c= "{t: new Date("+quote+ element2+quote+")" +"," + "  y: " + desired_value*100 +"},";  
  console.log(c);
  };

 */ 
/*
  const Production = [
    {t: new Date("01-04-22"),  y: 9.210526315789473},
    {t: new Date("01-05-22"),  y: 15.789473684210526},
    {t: new Date("01-06-22"),  y: 13.157894736842104},
    {t: new Date("01-07-22"),  y: 14.473684210526317},
    {t: new Date("01-10-22"),  y: 18.421052631578945},
    {t: new Date("01-11-22"),  y: 11.842105263157894},
    {t: new Date("01-12-22"),  y: 9.210526315789473},
    {t: new Date("01-13-22"),  y: 6.578947368421052},
    {t: new Date("01-18-22"),  y: 10.526315789473683},
    {t: new Date("01-19-22"),  y: 10.526315789473683},
    {t: new Date("01-20-22"),  y: 8.571428571428571},
    {t: new Date("01-21-22"),  y: 15.714285714285714},
    {t: new Date("01-24-22"),  y: 8.571428571428571},
    {t: new Date("01-25-22"),  y: 2.857142857142857},
    {t: new Date("01-26-22"),  y: 8.571428571428571},
    {t: new Date("01-27-22"),  y: 11.428571428571429},
    {t: new Date("01-28-22"),  y: 11.428571428571429},
    {t: new Date("01-31-22"),  y: 15.714285714285714}
    ]
    var a = 0; 
    for (i=0; i < Production.length; i++)
    {  a+=Production[i].y; }
   a = a/Production.length;
console.log(a);
   
 */ 

console.log();
console.log("Materials");
for (const element of June) {
  var workbook = XLSX.readFile(element);
  let worksheet = workbook.Sheets[workbook.SheetNames[0]];
  const dataExcel = XLSX.utils.sheet_to_json(worksheet);  
  var address_of_cell = 'K6';
  var desired_cell = worksheet[address_of_cell];
  var desired_value = desired_cell.v;    
let element1 = element.replace("C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount ", "");  
let element2 = element1.replace(".xlsx", "");  
var quote  = "\"";  
var c= "{t: new Date("+quote+ element2+quote+")" +"," + "  y: " + desired_value*100 +"},";  
console.log(c);
};


console.log();
console.log("Injection");

for (const element of June) {
  var workbook = XLSX.readFile(element);
  let worksheet = workbook.Sheets[workbook.SheetNames[0]];
  const dataExcel = XLSX.utils.sheet_to_json(worksheet);  
  var address_of_cell = 'K7';
  var desired_cell = worksheet[address_of_cell];
  var desired_value = desired_cell.v;    
let element1 = element.replace("C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount ", "");  
let element2 = element1.replace(".xlsx", "");  
var quote  = "\"";  
var c= "{t: new Date("+quote+ element2+quote+")" +"," + "  y: " + desired_value*100 +"},";  
console.log(c);
};

console.log();
console.log("Assembly Wiley Road");

for (const element of June) {
  var workbook = XLSX.readFile(element);
  let worksheet = workbook.Sheets[workbook.SheetNames[0]];
  const dataExcel = XLSX.utils.sheet_to_json(worksheet);  
  var address_of_cell = 'K8';
  var desired_cell = worksheet[address_of_cell];
  var desired_value = desired_cell.v;    
let element1 = element.replace("C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount ", "");  
let element2 = element1.replace(".xlsx", "");  
var quote  = "\"";  
var c= "{t: new Date("+quote+ element2+quote+")" +"," + "  y: " + desired_value*100 +"},";  
console.log(c);
};


console.log();
console.log("Redding/Jane");

for (const element of June) {
  var workbook = XLSX.readFile(element);
  let worksheet = workbook.Sheets[workbook.SheetNames[0]];
  const dataExcel = XLSX.utils.sheet_to_json(worksheet);  
  var address_of_cell = 'K9';
  var desired_cell = worksheet[address_of_cell];
  var desired_value = desired_cell.v;    
let element1 = element.replace("C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount ", "");  
let element2 = element1.replace(".xlsx", "");  
var quote  = "\"";  
var c= "{t: new Date("+quote+ element2+quote+")" +"," + "  y: " + desired_value*100 +"},";  
console.log(c);
};


console.log();
console.log("Quality");

for (const element of June) {
  var workbook = XLSX.readFile(element);
  let worksheet = workbook.Sheets[workbook.SheetNames[0]];
  const dataExcel = XLSX.utils.sheet_to_json(worksheet);  
  var address_of_cell = 'K10';
  var desired_cell = worksheet[address_of_cell];
  var desired_value = desired_cell.v;    
let element1 = element.replace("C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount ", "");  
let element2 = element1.replace(".xlsx", "");  
var quote  = "\"";  
var c= "{t: new Date("+quote+ element2+quote+")" +"," + "  y: " + desired_value*100 +"},";  
console.log(c);
};


console.log();
console.log("Shipping");

for (const element of June) {
  var workbook = XLSX.readFile(element);
  let worksheet = workbook.Sheets[workbook.SheetNames[0]];
  const dataExcel = XLSX.utils.sheet_to_json(worksheet);  
  var address_of_cell = 'K11';
  var desired_cell = worksheet[address_of_cell];
  var desired_value = desired_cell.v;    
let element1 = element.replace("C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount ", "");  
let element2 = element1.replace(".xlsx", "");  
var quote  = "\"";  
var c= "{t: new Date("+quote+ element2+quote+")" +"," + "  y: " + desired_value*100 +"},";  
console.log(c);
};


console.log();
console.log("Total for SEG");

for (const element of June) {
  var workbook = XLSX.readFile(element);
  let worksheet = workbook.Sheets[workbook.SheetNames[0]];
  const dataExcel = XLSX.utils.sheet_to_json(worksheet);  
  var address_of_cell = 'K12';
  var desired_cell = worksheet[address_of_cell];
  var desired_value = desired_cell.v;    
let element1 = element.replace("C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount ", "");  
let element2 = element1.replace(".xlsx", "");  
var quote  = "\"";  
var c= "{t: new Date("+quote+ element2+quote+")" +"," + "  y: " + desired_value*100 +"},";  
console.log(c);
};


console.log();
console.log("Total for Staffing");

for (const element of June) {
  var workbook = XLSX.readFile(element);
  let worksheet = workbook.Sheets[workbook.SheetNames[0]];
  const dataExcel = XLSX.utils.sheet_to_json(worksheet);  
  var address_of_cell = 'J12';
  var desired_cell = worksheet[address_of_cell];
  var desired_value = desired_cell.v;    
let element1 = element.replace("C:/Users/SOOMIN-SAC-217/Graph JS/PATH/ExcelSheetShow/ExcelSheet/Total/Daily Headcount ", "");  
let element2 = element1.replace(".xlsx", "");  
var quote  = "\"";  
var c= "{t: new Date("+quote+ element2+quote+")" +"," + "  y: " + desired_value*100 +"},";  
console.log(c);
};

//  console.log(c);

//  console.log(dataExcel); 
 

//  node ./FromExcel1.js

